import { formatRIF, validateRIF } from '../../utils/formatters';
import { CompanySettings } from '../../services/companyService.tsx';
import { authService } from '../../services/authService';